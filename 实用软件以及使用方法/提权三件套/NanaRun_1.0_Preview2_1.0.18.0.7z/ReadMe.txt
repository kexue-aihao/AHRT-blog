﻿#娜娜润

应用程序运行时环境定制实用程序

## 组件开发情况

- [x] 闵须藤
- [] NanaEAM
- [] NanaKit
- [ ] 娜娜润 (Windows)
- [] NanaRun（控制台）
- [ ] 跑酷 (SDK)

## 闵须藤

MinSudo 是适用于 Windows 的轻量级 POSIX 风格的 Sudo 实现。

它使用户可以在非提升的控制台中使用提升的控制台应用程序。

为了安全起见，实现使用 UAC 进行提升，不支持
凭据缓存。它也不使用自制的 Windows 服务和任何 IPC
基础设施。

这是用法。

```
格式：MinSudo [ 选项 ] 命令

选项：

  --NoLogo 禁止版权信息。
  --verbose 显示详细信息。
  --WorkDir=[ Path ] 设置工作目录。
  --System 以系统而不是管理员身份运行。
  --TrustedInstaller 以 TrustedInstaller 而不是管理员身份运行。
  --Privileged 启用所有权限。

  --Version 显示版本信息。

  /?显示此内容。
  -H 显示此内容。
  --帮助显示此内容。

笔记：

  - 所有命令选项都不区分大小写。
  - 如果您不指定其他命令，MinSudo 将执行“cmd.exe”。
  - 您可以使用“/”或“--”覆盖“-”并使用“=”覆盖“:”
    命令行参数。例如，“/Option:Value”和
    “-Option=Value”是等价的。

例子：

  如果您想在未提升的控制台中以提升的方式运行“whoami /all”，并且
  你不想显示 MinSudo 的版本信息。
  > MinSudo --NoLogo whoami /all
```

# NanaRun

Application runtime environment customization utility

## Development Status of Components

- [x] MinSudo
- [ ] NanaEAM
- [ ] NanaKit
- [ ] NanaRun (Windows)
- [ ] NanaRun (Console)
- [ ] NanaRun (SDK)

## MinSudo

MinSudo is a lightweight POSIX-style Sudo implementation for Windows.

It makes user possible to use elevated console apps in non-elevated consoles.

For safety, the implementation uses the UAC for elevation and don't support
credential cache. It also don't use homemade Windows service and any IPC 
infrastructures.

Here is the usage.

```
Format: MinSudo [ Options ] Command

Options:

  --NoLogo Suppress copyright message.
  --Verbose Show detailed information.
  --WorkDir=[ Path ] Set working directory.
  --System Run as System instead of Administrator.
  --TrustedInstaller Run as TrustedInstaller instead of Administrator.
  --Privileged Enable all privileges.

  --Version Show version information.

  /? Show this content.
  -H Show this content.
  --Help Show this content.

Notes:

  - All command options are case-insensitive.
  - MinSudo will execute "cmd.exe" if you don't specify another command.
  - You can use the "/" or "--" override "-" and use the "=" override ":" in 
    the command line parameters. For example, "/Option:Value" and 
    "-Option=Value" are equivalent.

Example:

  If you want to run "whoami /all" as elevated in the non-elevated Console, and
  you don't want to show version information of MinSudo.
  > MinSudo --NoLogo whoami /all
```
